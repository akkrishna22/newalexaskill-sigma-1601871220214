import ask_sdk_core
from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler, AbstractExceptionHandler
from ask_sdk_core.utils import is_request_type, is_intent_name
sb = SkillBuilder()


class LaunchRequestHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_request_type("LaunchRequest")(handler_input)
    
    def handle(self, handler_input):
        speech_text = 'Welcome to my benefits Program, How can i help you today ?';
        handler_input.response_builder.speak(speech_text).set_should_end_session(False)
        return handler_input.response_builder.response

class GetBenefitsIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("GetBenefitsIntent")(handler_input)

    def handle(self, handler_input):
        #slotValue = handler_input.request_envelope.request.intent.slots['slotName'].value
        speech_text = "Sure. We have Silver, Gold, Platinum plans available. Which one would you like to know about";
        handler_input.response_builder.speak(speech_text).set_should_end_session(False)
        return handler_input.response_builder.response

class GoldPlanIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        return is_intent_name("GoldPlanIntent")(handler_input)

    def handle(self, handler_input):
        #slotValue = handler_input.request_envelope.request.intent.slots['slotName'].value
        speech_text = "Sure. Gold plan comes with a deductible of $1250 for individual and $2500 for family";
        handler_input.response_builder.speak(speech_text).set_should_end_session(False)
        return handler_input.response_builder.response

class ErrorHandler(AbstractExceptionHandler):
    def can_handle(self, handler_input, exception):
        return True

    def handle(self, handler_input, exception):
        speech_text = 'Sorry, your skill encountered an error';
        print(exception)
        handler_input.response_builder.speak(speech_text).set_should_end_session(False)
        return handler_input.response_builder.response


#delete undefined built-in intent handlers
sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(GetBenefitsIntentHandler())
sb.add_request_handler(GoldPlanIntentHandler())
sb.add_exception_handler(ErrorHandler())
#add custom request handlers
#sb.add_request_handler(CustomIntentHandler())

def handler(event, context):
    return sb.lambda_handler()(event, context)
